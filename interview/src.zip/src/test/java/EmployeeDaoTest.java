import com.epoint.interview.dao.EmployeeInfoDao;
import com.epoint.interview.dao.InterviewInfoDao;
import com.epoint.interview.domain.EmployeeInfo;
import com.epoint.interview.domain.InterviewInfo;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class EmployeeDaoTest {
    @Test
    public void test1() {
        ApplicationContext ioc = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeInfoDao employeeInfoDao = (EmployeeInfoDao) ioc.getBean("employeeInfoDao");
        //EmployeeInfo employeeInfo = employeeInfoDao.queryEmployeeInfoByeId("1186f137-ee1f-4dd0-ac10-fb03dbf19ea3");
        //System.out.println(employeeInfo);
        //int pageIndex, int pageSize, String eName, Integer job
/*        Map<String,Object> query =  new HashMap<>();
        int pageIndex =1;
        int pageSize = 1;
        int offset = pageIndex * pageSize;
        query.put("offset",offset);
        query.put("pageSize",pageSize);
        List<EmployeeInfo> employeeInfos = employeeInfoDao.queryEmployeeInfoByKeyWords(query);
        for (EmployeeInfo employeeInfo: employeeInfos) {
            System.out.println(employeeInfo);
        }*/
       /* boolean b = employeeInfoDao.checkIdNumber("111111111111111111");
        System.out.println(b);*/
        for(int i=0;i<100;i++){
            EmployeeInfo employeeInfo = new EmployeeInfo();
            employeeInfo.seteId(UUID.randomUUID().toString());
            employeeInfo.seteName(UUID.randomUUID().toString());
            employeeInfo.setIdNumber(UUID.randomUUID().toString());
            employeeInfo.setInterview(UUID.randomUUID().toString());
            employeeInfo.setSchool(UUID.randomUUID().toString());
            employeeInfo.setJob((int) (Math.random()*3));
            employeeInfo.setEducation((int) (Math.random()*3));
            employeeInfo.setSalary((int) (Math.random()*1000));
            employeeInfoDao.addEmployeeInfo(employeeInfo);
        }

    }

    @Test
    public void test2() {
        /*ApplicationContext ioc = new ClassPathXmlApplicationContext("applicationContext.xml");
        InterviewInfoDao interviewInfoDao = (InterviewInfoDao) ioc.getBean("interviewInfoDao");
        String s = interviewInfoDao.newInterviewId();
        System.out.println(s); //null service层判断*/
        InterviewInfo interviewInfo = null;
        System.out.println(interviewInfo.geteId());
    }

}
