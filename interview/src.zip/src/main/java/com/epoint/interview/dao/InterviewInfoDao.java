package com.epoint.interview.dao;

import com.epoint.interview.domain.InterviewInfo;

import java.util.List;
import java.util.Map;

public interface InterviewInfoDao {
    /**
     * 列表查询
     * int pageIndex, int pageSize, String sortField, String sortOrder
     * query
     *
     * @return
     */
    public List<InterviewInfo> queryInterviewInfos(Map<String, Object> query);

    /**
     * 添加面试信息
     *
     * @param interviewInfo
     * @return
     */
    public int addInterviewInfo(InterviewInfo interviewInfo);

    /**
     * 删除面试信息
     *
     * @param interviewId
     * @return
     */
    public int deleteInterviewInfoById(String interviewId);

    /**
     * 级联删除面试信息
     * @param eId
     * @return
     */
    public int deleteInterviewInfoByeId(String eId);

    /**
     * 列表总长度
     *
     * @return
     */
    public int findLength();

    /**
     * 系统生成的编号
     *
     * @return
     */
    public String newInterviewId();

    /**
     * 根据编号查询
     *
     * @param interviewId
     * @return
     */
    public InterviewInfo queryInterviewById(String interviewId);

    /**
     * 查询面试的次数
     *
     * @param eId
     * @return
     */
    public List<InterviewInfo> queryInterviewByEid(String eId);

    /**
     * 查询面试官
     *
     * @param eId
     * @return
     */
    public String queryInterviewer(String eId);

    /**
     * 查询第一次的面试结果
     *
     * @param eId
     * @return
     */
    public String queryInterviewResult(String eId);

}
