package com.epoint.interview.service;

import com.epoint.interview.domain.EmployeeInfo;

import java.util.List;
import java.util.Map;

public interface EmployeeInfoService {

    /**
     * 根据员工姓名，投递岗位模糊查询
     * #{offset} int pageIndex, int pageSize, String eName, Integer job
     * query
     *
     * @return
     */
    public List<EmployeeInfo> queryEmployeeInfoByKeyWords(Map<String, Object> query);

    /**
     * 查询数据表中满足查询条件的记录条数
     * String eName, Integer job
     *
     * @return
     */
    public int findLength(Map<String, Object> query);

    /**
     * 增加员工信息
     *
     * @param employeeInfo
     * @return
     */
    public String addEmployeeInfo(EmployeeInfo employeeInfo);

    /**
     * 根据员工编号查询员工信息
     *
     * @param eId
     * @return
     */
    public EmployeeInfo queryEmployeeInfoByeId(String eId);

    /**
     * 根据编号更新员工信息
     *
     * @param employeeInfo
     * @return
     */
    public String updateEmployeeInfoByEid(EmployeeInfo employeeInfo);

    /**
     * 删除员工信息的同时，删除所有的面试信息。
     *
     * @param eId
     * @return
     */
    public String deleteEmployeeInfo(String eId);

}
