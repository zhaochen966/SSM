package com.epoint.interview.domain;

import java.util.Date;

/**
 * 面试信息类
 */
public class InterviewInfo {
    private String interviewId;
    private String eId;
    private String interviewer;
    private Date interviewTime;
    private Integer writeGrade;
    private Integer interviewGrade;
    private Double totalGrade;
    private String notes;

    @Override
    public String toString() {
        return "InterviewInfo{" +
                "interviewId='" + interviewId + '\'' +
                ", eId='" + eId + '\'' +
                ", interviewer='" + interviewer + '\'' +
                ", interviewTime=" + interviewTime +
                ", writeGrade=" + writeGrade +
                ", interviewGrade=" + interviewGrade +
                ", totalGrade=" + totalGrade +
                ", notes='" + notes + '\'' +
                '}';
    }

    public InterviewInfo() {
    }

    public InterviewInfo(String interviewId, String eId, String interviewer, Date interviewTime, Integer writeGrade, Integer interviewGrade, Double totalGrade, String notes) {
        this.interviewId = interviewId;
        this.eId = eId;
        this.interviewer = interviewer;
        this.interviewTime = interviewTime;
        this.writeGrade = writeGrade;
        this.interviewGrade = interviewGrade;
        this.totalGrade = totalGrade;
        this.notes = notes;
    }

    public String getInterviewId() {
        return interviewId;
    }

    public void setInterviewId(String interviewId) {
        this.interviewId = interviewId;
    }

    public String geteId() {
        return eId;
    }

    public void seteId(String eId) {
        this.eId = eId;
    }

    public String getInterviewer() {
        return interviewer;
    }

    public void setInterviewer(String interviewer) {
        this.interviewer = interviewer;
    }

    public Date getInterviewTime() {
        return interviewTime;
    }

    public void setInterviewTime(Date interviewTime) {
        this.interviewTime = interviewTime;
    }

    public Integer getWriteGrade() {
        return writeGrade;
    }

    public void setWriteGrade(Integer writeGrade) {
        this.writeGrade = writeGrade;
    }

    public Integer getInterviewGrade() {
        return interviewGrade;
    }

    public void setInterviewGrade(Integer interviewGrade) {
        this.interviewGrade = interviewGrade;
    }

    public Double getTotalGrade() {
        return totalGrade;
    }

    public void setTotalGrade(Double totalGrade) {
        this.totalGrade = totalGrade;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
