package com.epoint.interview.service.impl;

import com.epoint.interview.dao.EmployeeInfoDao;
import com.epoint.interview.dao.InterviewInfoDao;
import com.epoint.interview.domain.EmployeeInfo;
import com.epoint.interview.service.EmployeeInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class EmployeeInfoServiceImpl implements EmployeeInfoService {

    @Autowired
    private EmployeeInfoDao employeeInfoDao;
    @Autowired
    private InterviewInfoDao interviewInfoDao;

    @Override
    public List<EmployeeInfo> queryEmployeeInfoByKeyWords(Map<String, Object> query) {
        return employeeInfoDao.queryEmployeeInfoByKeyWords(query);
    }

    @Override
    public int findLength(Map<String, Object> query) {
        return employeeInfoDao.findLength(query);
    }

    /**
     * 添加员工信息，确保身份证号码唯一
     *
     * @param employeeInfo
     * @return
     */
    @Override
    public String addEmployeeInfo(EmployeeInfo employeeInfo) {
        boolean b = employeeInfoDao.checkIdNumber(employeeInfo.getIdNumber());
        if (b) {
            return "添加失败，身份证号重复！";
        }
        int i = employeeInfoDao.addEmployeeInfo(employeeInfo);
        if (i > 0) {
            return "添加成功！";
        } else {
            return "添加失败！";
        }
    }

    @Override
    public EmployeeInfo queryEmployeeInfoByeId(String eId) {
        return employeeInfoDao.queryEmployeeInfoByeId(eId);
    }

    /**
     * 更新员工信息
     *
     * @param employeeInfo
     * @return
     */
    @Override
    public String updateEmployeeInfoByEid(EmployeeInfo employeeInfo) {
        int i = employeeInfoDao.updateEmployeeInfoByEid(employeeInfo);
        if (i > 0) {
            return "更新成功！";
        } else {
            return "更新失败";
        }
    }

    /**
     * 删除员工信息，并且进行级联删除面试表中的员工面试信息
     *
     * @param eId
     * @return
     */
    @Override
    public String deleteEmployeeInfo(String eId) {
        StringBuffer success = new StringBuffer("");
        StringBuffer error = new StringBuffer("");
        int successCount = 0;
        int errorCount = 0;
        if (eId.contains(",")) {
            String[] splits = eId.split(",");
            for (String split : splits) {
                EmployeeInfo employeeInfo = employeeInfoDao.queryEmployeeInfoByeId(split);
                String eName = employeeInfo.geteName();
                int i = employeeInfoDao.deleteEmployeeInfo(split);
                /**
                 * 事务管理，级联删除面试表里面的记录
                 */
                interviewInfoDao.deleteInterviewInfoByeId(split);
                if (i > 0) {
                    success.append(eName).append(",");
                    successCount++;
                } else {
                    error.append(eName).append(",");
                    errorCount++;
                }
            }
            String successString = success.toString().substring(0, success.length() - 1);
            if (errorCount == 0) {
                return successString + "删除成功，总共删除" + successCount + "条数据";
            } else {
                String errorString = error.toString().substring(0, error.length() - 1);
                return successString + "删除成功" + errorString + "删除失败！";
            }
        } else {
            EmployeeInfo employeeInfo = employeeInfoDao.queryEmployeeInfoByeId(eId);
            String eName = employeeInfo.geteName();
            int i = employeeInfoDao.deleteEmployeeInfo(eId);
            //级联删除面试表
            interviewInfoDao.deleteInterviewInfoByeId(eId);
            //int j = 1/0;
            if (i > 0) {
                return eName + "删除成功！";
            } else {
                return eName + "删除失败！";
            }
        }
    }

}
