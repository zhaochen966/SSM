package com.epoint.interview.dao;

import com.epoint.interview.domain.EmployeeInfo;

import java.util.List;
import java.util.Map;

public interface EmployeeInfoDao {

    /**
     * 根据员工姓名，投递岗位模糊查询
     * <p>
     * int pageIndex, int pageSize, String eName, Integer job
     * query
     *
     * @return
     */
    public List<EmployeeInfo> queryEmployeeInfoByKeyWords(Map<String, Object> query);

    /**
     * 查询数据表中满足查询条件的记录条数
     *
     * @return
     */
    public int findLength(Map<String, Object> query);

    /**
     * 增加员工信息
     *
     * @param employeeInfo
     * @return
     */
    public int addEmployeeInfo(EmployeeInfo employeeInfo);

    /**
     * 根据员工编号查询员工信息
     *
     * @param eId
     * @return
     */
    public EmployeeInfo queryEmployeeInfoByeId(String eId);

    /**
     * 根据编号更新员工信息
     *
     * @param employeeInfo
     * @return
     */
    public int updateEmployeeInfoByEid(EmployeeInfo employeeInfo);

    /**
     * 删除员工信息
     *
     * @param eId
     * @return
     */
    public int deleteEmployeeInfo(String eId);

    /**
     * 校验身份证号码
     *
     * @param idNumber
     * @return true 存在
     */
    public boolean checkIdNumber(String idNumber);
}
