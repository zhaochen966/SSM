package com.epoint.interview.service.impl;

import com.epoint.interview.dao.EmployeeInfoDao;
import com.epoint.interview.dao.InterviewInfoDao;
import com.epoint.interview.domain.EmployeeInfo;
import com.epoint.interview.domain.InterviewInfo;
import com.epoint.interview.service.InterviewInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
public class InterviewInfoServiceImpl implements InterviewInfoService {

    @Autowired
    private InterviewInfoDao interviewInfoDao;

    @Autowired
    private EmployeeInfoDao employeeInfoDao;

    @Override
    public List<InterviewInfo> queryInterviewInfos(Map<String, Object> query) {
        return interviewInfoDao.queryInterviewInfos(query);
    }

    /**
     * 添加面试信息
     * ① 需要进行次数的判断 <2
     * ② 考核通过就不能添加
     * ③ 修改员工表中的内容
     *
     * @param interviewInfo
     * @return
     */
    @Override
    public String addInterviewInfo(InterviewInfo interviewInfo) {
        //查询是否已经面试过了
        List<InterviewInfo> oldInterviewInfo = interviewInfoDao.queryInterviewByEid(interviewInfo.geteId());
        if (oldInterviewInfo.size()!=0) {
            if (oldInterviewInfo.size() < 2) {
                //查询两次的面试官
                String newInterviewer = interviewInfo.getInterviewer();
                String oldInterviewer = oldInterviewInfo.get(0).getInterviewer();
                //查询成绩
                Double oldInterviewInfoTotalGrade = oldInterviewInfo.get(0).getTotalGrade();
                if (oldInterviewInfoTotalGrade >= 60) {
                    return "已经面试通过，添加失败！";
                }
                if (newInterviewer.equals(oldInterviewer)) {
                    return "面试官相同，添加失败！";
                }
                //如果成绩 > 60
                return add(interviewInfo);
            } else {
                //已经超过2次
                return "已经面试2次，添加失败！";
            }
        } else {
            //没有参加面试的情况
            return add(interviewInfo);
        }
    }

    /**
     * 添加员工的子引用
     *
     * @param interviewInfo
     * @return
     */
    public String add(InterviewInfo interviewInfo) {
        //查询人员信息
        EmployeeInfo employeeInfo = employeeInfoDao.queryEmployeeInfoByeId(interviewInfo.geteId());
        //如果成绩 > 60
        if (interviewInfo.getTotalGrade() >= 60) {
            employeeInfo.setInterview("面试通过");
        } else {
            employeeInfo.setInterview("面试未通过");
        }
        //事务管理 TODO
        employeeInfoDao.updateEmployeeInfoByEid(employeeInfo);
        //插入操作
        int j = interviewInfoDao.addInterviewInfo(interviewInfo);
        if (j > 0) {
            return "添加成功！";
        } else {
            return "添加失败！";
        }

    }

    /**
     * 删除
     *
     * @param interviewId
     * @return
     */
    @Override
    public String deleteInterviewInfoById(String interviewId) {
        int i = interviewInfoDao.deleteInterviewInfoById(interviewId);
        if (i > 0) {
            return "删除成功！";
        } else {
            return "删除失败！";
        }
    }

    /**
     * 查询总人数
     * @return
     */
    @Override
    public int findLength() {
        return interviewInfoDao.findLength();
    }

    /**
     * 返回新生成的面试编号
     *
     * @return
     */
    @Override
    public String newInterviewId() {
        String newInterviewId = interviewInfoDao.newInterviewId();
        if (newInterviewId == null) {
            LocalDate localDate = LocalDate.now();
            String yyyy = localDate.format(DateTimeFormatter.ofPattern("yyyy"));
            newInterviewId = "EP" + yyyy + "0001";
        }
        return newInterviewId;
    }

    @Override
    public InterviewInfo queryInterviewById(String interviewId) {
        return interviewInfoDao.queryInterviewById(interviewId);
    }

}
