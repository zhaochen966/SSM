package com.epoint.interview.controller;

import com.alibaba.fastjson.JSON;
import com.epoint.interview.domain.EmployeeInfo;
import com.epoint.interview.domain.InterviewInfo;
import com.epoint.interview.service.EmployeeInfoService;
import com.epoint.interview.service.InterviewInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/interviewinfo")
public class InterviewController {

    @Autowired
    private InterviewInfoService interviewInfoService;
    @Autowired
    private EmployeeInfoService employeeInfoService;

    /**
     * 查询所有面试信息
     *
     * @param sortField
     * @param sortOrder
     * @param pageIndex
     * @param pageSize
     * @return
     */
    @RequestMapping("/queryinterviewinfos")
    @ResponseBody
    public Map<String, Object> list(
            @RequestParam(name = "sortField", defaultValue = "") String sortField,
            @RequestParam(name = "sortOrder", defaultValue = "") String sortOrder,
            @RequestParam(name = "pageIndex") Integer pageIndex,
            @RequestParam(name = "pageSize") Integer pageSize) {
        Map<String, Object> query = new HashMap<>();
        Map<String, Object> ret = new HashMap<>();
        query.put("sortField", sortField);
        query.put("sortOrder", sortOrder);
        query.put("offset", pageIndex * pageSize);
        query.put("pageSize", pageSize);
        List<InterviewInfo> interviewInfos = interviewInfoService.queryInterviewInfos(query);
        int total = interviewInfoService.findLength();

        //by epoint practise
        List<Map<String, Object>> data = new ArrayList<>();
        for (InterviewInfo interviewInfo : interviewInfos) {
            Map<String, Object> map = new HashMap<>();
            String eId = interviewInfo.geteId();
            EmployeeInfo employeeInfo = employeeInfoService.queryEmployeeInfoByeId(eId);
            String eName = employeeInfo.geteName();
            map.put("eName", eName);
            map.put("eId", eId);
            map.put("interviewer", interviewInfo.getInterviewer());
            map.put("interviewGrade", interviewInfo.getInterviewGrade());
            map.put("interviewId", interviewInfo.getInterviewId());
            map.put("interviewTime", interviewInfo.getInterviewTime());
            map.put("totalGrade", interviewInfo.getTotalGrade());
            map.put("writeGrade", interviewInfo.getWriteGrade());
            map.put("notes", interviewInfo.getNotes());
            data.add(map);
        }
        //ret.put("data",interviewInfos);
        ret.put("data", data);
        ret.put("total", total);
        return ret;
    }

    /**
     * 删除面试信息
     *
     * @param interviewId
     * @return
     */
    @ResponseBody
    @RequestMapping("/deleteinterviewinfobyid/{interviewId}")
    public String delete(@PathVariable("interviewId") String interviewId) {
        return interviewInfoService.deleteInterviewInfoById(interviewId);
    }

    /**
     * 根据编号查询
     *
     * @param interviewId
     * @return
     */
    @ResponseBody
    @RequestMapping("/queryinterviewbyid/{interviewId}")
    public Map<String, Object> queryInterviewById(@PathVariable("interviewId") String interviewId) {
        InterviewInfo interviewInfo = interviewInfoService.queryInterviewById(interviewId);
        String eId = interviewInfo.geteId();
        EmployeeInfo employeeInfo = employeeInfoService.queryEmployeeInfoByeId(eId);
        String eName = employeeInfo.geteName();
        Map<String, Object> ret = new HashMap<>();
        ret.put("eName", eName);
        ret.put("interviewId", interviewInfo.getInterviewId());
        ret.put("interviewer", interviewInfo.getInterviewer());
        ret.put("interviewTime", interviewInfo.getInterviewTime());
        ret.put("writeGrade", interviewInfo.getWriteGrade());
        ret.put("interviewGrade", interviewInfo.getInterviewGrade());
        ret.put("totalGrade", interviewInfo.getTotalGrade());
        ret.put("notes", interviewInfo.getNotes());
        return ret;
    }

    /**
     * 显示所有的人员姓名
     *
     * @return
     */
    @ResponseBody
    @RequestMapping("/queryemployeeall")
    public List<EmployeeInfo> queryEmployeeAll() {
        return employeeInfoService.queryEmployeeInfoByKeyWords(null);
    }

    /**
     * 返回新的员工编号
     *
     * @return
     */
    @ResponseBody
    @RequestMapping("/newinterviewid")
    public String newInterviewId() {
        return interviewInfoService.newInterviewId();
    }

    /**
     * 添加员工信息
     *
     * @param data
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addinterviewinfo", method = RequestMethod.POST)
    public String addInterviewInfo(String data) {
        data = data.substring(1, data.length() - 1);
        InterviewInfo interviewInfo = JSON.parseObject(data, InterviewInfo.class);
        return interviewInfoService.addInterviewInfo(interviewInfo);
    }

}
