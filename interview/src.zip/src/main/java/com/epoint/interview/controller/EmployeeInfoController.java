package com.epoint.interview.controller;

import com.alibaba.fastjson.JSON;
import com.epoint.interview.domain.EmployeeInfo;
import com.epoint.interview.service.EmployeeInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RequestMapping("/employeeinfo")
@Controller
public class EmployeeInfoController {

    @Autowired
    private EmployeeInfoService employeeInfoService;

    /**
     * 查询列表
     *
     * @param eName
     * @param job
     * @param pageIndex
     * @param pageSize
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryemployeeinfobykeywords", method = RequestMethod.POST)
    public Map<String,Object> list(
            @RequestParam(name = "eName", defaultValue = "", required = false) String eName,
            @RequestParam(name = "job", required = false) Integer job,
            @RequestParam(name = "pageIndex") Integer pageIndex,
            @RequestParam(name = "pageSize") Integer pageSize) {
        Map<String, Object> query = new HashMap<>();
        Map<String, Object> ret = new HashMap<>();
        query.put("offset", pageIndex * pageSize);
        query.put("pageSize", pageSize);
        query.put("eName", eName);
        query.put("job", job);
        List<EmployeeInfo> data = employeeInfoService.queryEmployeeInfoByKeyWords(query);
        int total = employeeInfoService.findLength(query);
        ret.put("data",data);
        ret.put("total",total);
        return ret;
    }

    /**
     * 添加员工信息
     *
     * @param data
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addemployeeinfo", method = RequestMethod.POST)
    public String addemployeeinfo(String data) {
        data = data.substring(1, data.length() - 1);
        EmployeeInfo employeeInfo = JSON.parseObject(data, EmployeeInfo.class);
        employeeInfo.seteId(UUID.randomUUID().toString());
        String result = employeeInfoService.addEmployeeInfo(employeeInfo);
        return result;
    }

    /**
     * 删除员工信息
     *
     * @param eId
     * @return
     */
    @RequestMapping(value = "/deleteemployeeinfo", method = RequestMethod.POST)
    @ResponseBody
    public String deleteEmployeeInfo(String eId) {
        return employeeInfoService.deleteEmployeeInfo(eId);
    }

    /**
     * 根据编号查询
     * @param eId
     * @return
     */
    @RequestMapping(value = "/queryemployeeinfobyeid/{eId}",method = RequestMethod.GET)
    @ResponseBody
    public EmployeeInfo queryEmployeeInfoByEid(@PathVariable("eId") String eId){
        return employeeInfoService.queryEmployeeInfoByeId(eId);
    }

    /**
     * 更新
     * @param data
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "updateemployeeinfobyeid",method = RequestMethod.POST)
    public String update(String data){
        data = data.substring(1,data.length()-1);
        EmployeeInfo employeeInfo = JSON.parseObject(data, EmployeeInfo.class);
        return employeeInfoService.updateEmployeeInfoByEid(employeeInfo);
    }

}
