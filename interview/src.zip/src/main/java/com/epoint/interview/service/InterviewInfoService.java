package com.epoint.interview.service;

import com.epoint.interview.domain.InterviewInfo;

import java.util.List;
import java.util.Map;

public interface InterviewInfoService {
    /**
     * 列表查询
     * int pageIndex, int pageSize, String sortField, String sortOrder
     * query
     *
     * @return
     */
    public List<InterviewInfo> queryInterviewInfos(Map<String, Object> query);

    /**
     * 添加
     *
     * @param interviewInfo
     * @return
     */
    public String addInterviewInfo(InterviewInfo interviewInfo);

    /**
     * 添加员工的子引用
     * @param interviewInfo
     * @return
     */
    public String add(InterviewInfo interviewInfo);

    /**
     * 删除
     *
     * @param interviewId
     * @return
     */
    public String deleteInterviewInfoById(String interviewId);

    /**
     * 列表总长度
     *
     * @return
     */
    public int findLength();

    /**
     * 系统生成的编号
     *
     * @return
     */
    public String newInterviewId();

    /**
     * 根据编号查询
     *
     * @param interviewId
     * @return
     */
    public InterviewInfo queryInterviewById(String interviewId);

}
