package com.epoint.interview.domain;

/**
 * 员工信息类
 */
public class EmployeeInfo {
    private String eId;
    private String eName;
    private String idNumber;
    private Integer education;
    private String school;
    private Integer job;
    private Integer salary;
    private String interview;

    @Override
    public String toString() {
        return "EmployeeInfo{" +
                "eId='" + eId + '\'' +
                ", eName='" + eName + '\'' +
                ", idNumber='" + idNumber + '\'' +
                ", education=" + education +
                ", school='" + school + '\'' +
                ", job=" + job +
                ", salary=" + salary +
                ", interview='" + interview + '\'' +
                '}';
    }

    public String geteId() {
        return eId;
    }

    public void seteId(String eId) {
        this.eId = eId;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Integer getEducation() {
        return education;
    }

    public void setEducation(Integer education) {
        this.education = education;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Integer getJob() {
        return job;
    }

    public void setJob(Integer job) {
        this.job = job;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public String getInterview() {
        return interview;
    }

    public void setInterview(String interview) {
        this.interview = interview;
    }

    public EmployeeInfo() {
    }

    public EmployeeInfo(String eId, String eName, String idNumber, Integer education, String school, Integer job, Integer salary, String interview) {
        this.eId = eId;
        this.eName = eName;
        this.idNumber = idNumber;
        this.education = education;
        this.school = school;
        this.job = job;
        this.salary = salary;
        this.interview = interview;
    }
}
